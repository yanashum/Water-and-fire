from enum import Enum


class PowerUpType(Enum):

    water = 0
    FIRE = 1

