from enum import Enum


class Algorithm(Enum):

    friend_2 = 0
    friend_1 = 1
    PLAYER = 2
    NONE = 3
